# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 12:12:13 2019

@author: Y.H
"""

import matplotlib
import matplotlib.pyplot as plt

def main(model, centers):
    labels = model.labels_
    color_list = ["r", "g", "b", "c", "m", "y", "k"]
    marker_list = ["o", "v", "^", "<", ">","s", "p", "*", "h", "H", "D", "d"]
    for i in range(len(centers)):
        plt.scatter(centers[i][0], centers[i][1], color = color_list[int(labels[i] % len(color_list))], 
                    alpha = 0.3, marker = marker_list[int(labels[i] / len(color_list))], 
                                                                     label='cluster-'+str(labels[i]))
        
    plt.grid(True)
    #plt.legend(loc='uppper right', bbox_to_anchor=(1.05, 0.5, 0.5, .100), borderaxespad=0.,)
    plt.savefig('result.png')
    plt.show()