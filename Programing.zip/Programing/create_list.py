# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 12:10:26 2019

@author: Y.H
"""

import numpy as np

def main(path, filters):
    vectors_list = []
    for i in range(filters):
        #フィルターへのパス取得
        filter_name = path + '\\' + str(i) + '.txt'
        vector = []
        
        #ファイルから読み込んでvectorに書き込む
        with open(filter_name) as f:
            l = [s.strip() for s in f.readlines()] 
            for j in range(len(l)):
                v = l[j].split()
                #print(vector)
                for s in range(len(v)):
                    v[s] = float(v[s])
                #print(vector)
                vector.append(v)
                
        vectors_list.append(vector)

    #print(len(vectors_list))
    
    return vectors_list