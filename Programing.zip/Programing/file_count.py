# -*- coding: utf-8 -*-
"""
Created on Thu Nov 28 15:33:23 2019

@author: Y.H
"""

import os

#パス取得
#path_base=os.path.normpath(os.path.join(os.path.abspath(__file__), '../filters'))

def main(path):    
    #パス内のすべてのファイル名をリスト化
    files=os.listdir(path)
    #print(files)

    #txtのみカウント
    count=0
    for i in files:
        item=i.split('.')
        if item[1]=='txt':
            count+=1
        
    #count_files = len(files) - 1 
    #print(count_files)
    return count

#直接file_count.pyを呼んだときのみfile_countを実行する
#if __name__ == '__main__':
#    file_count(path)