# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 15:15:37 2019

@author: Y.H
"""

import numpy as np
from sklearn import cluster
from sklearn.decomposition import PCA

def maximam_pca(vectors_list):
    #列数（次元）の最大値を求める
    len_max = 0
    for i in vectors_list:
        for j in i:
             if(len(j) > len_max):
                 len_max = len(j)
                 break
    #print(len_max)
             
    #各ベクトルの中心点を求める
    centers_ = np.empty((len(vectors_list), len_max))
    for i in range(len(vectors_list)):
        vectors = np.array(vectors_list[i])
        #print(vectors)
        
        #k-meansで中心点を求める
        model = cluster.KMeans(n_clusters=1).fit(vectors)
        center = model.cluster_centers_  
            
        #各ベクトルの列数（次元）を最大値に合わせる
        center = np.reshape(center, len(vectors[0]))
        center = np.append(center, np.zeros(len_max - len(center)))
        #print(center)
        #print(len(center))
        
        centers_[i] = center
        centers_.astype(np.float128)
        
        #主成分分析で2次元データに圧縮
        #print(centers_.shape)
        pca = PCA(n_components = 2)
        pca.fit(centers_)
        centers = pca.transform(centers_)
        #print(centers.shape)
        
    #print(centers)
    print(centers.dtype)
    return centers

def center_pca(vectors_list):
    #各ベクトルの中心点を求める
    centers = np.empty((len(vectors_list), 2))
    for i in range(len(vectors_list)):
        vectors_ = np.array(vectors_list[i])
        #print(vectors)
        
        #主成分分析で2次元データに圧縮
        pca = PCA(n_components = 2)
        pca.fit(vectors_)
        vectors = pca.transform(vectors_)
        
        #k-meansで中心点を求める
        model = cluster.KMeans(n_clusters=1).fit(vectors)
        center = model.cluster_centers_
        
        centers[i] = center
        return centers