# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 17:40:07 2019

@author: Y.H
"""

import numpy as np
from sklearn import cluster

def main(centers):
    model = cluster.AffinityPropagation().fit(centers)
    #print(model.labels_)
    
    return model