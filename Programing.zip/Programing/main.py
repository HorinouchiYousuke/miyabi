# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 11:39:04 2019

@author: Y.H
"""

import os
import numpy as np

import file_count
import create_list
import center_search
import center_clustering
import plot

path_input=os.path.normpath(os.path.join(os.path.abspath(__file__), '../filters'))
#print(path_input)
filters=file_count.main(path_input)
#print(filters)

vectors_list = create_list.main(path_input, filters)
#print(type(vectors_list))
#print(vectors_list)

centers = center_search.maximam_pca(vectors_list)
#centers = center_search.center_pca(vectors_list)
print(centers)

model = center_clustering.main(centers)
print(model.labels_)

plot.main(model, centers)