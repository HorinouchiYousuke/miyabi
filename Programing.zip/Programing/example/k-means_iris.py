# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 09:50:09 2019

@author: Y.H
"""

import matplotlib.pyplot as plt
from sklearn import cluster
from sklearn import datasets

iris = datasets.load_iris()
data = iris['data']

model = cluster.KMeans(n_clusters=3)
model.fit(data)

labels = model.labels_

ldata = data[labels == 0]
plt.scatter(ldata[:, 2], ldata[:, 3], c='red', alpha=0.3, s=100, marker="o")

ldata = data[labels == 1]
plt.scatter(ldata[:, 2], ldata[:, 3], c='blue', alpha=0.3, s=100, marker="^")

ldata = data[labels == 2]
plt.scatter(ldata[:, 2], ldata[:, 3], c='yellow', alpha=0.3, s=100, marker="*")

plt.xlabel(iris['feature_names'][2])
plt.ylabel(iris['feature_names'][3])