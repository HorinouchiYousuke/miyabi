# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 13:51:45 2019

@author: Y.H
"""

import matplotlib.pyplot as plt
import numpy as np
from sklearn import cluster

data1 = np.random.rand(100,2) / 2.0
data2 = np.random.rand(100,2) / 2.0 + 0.5
#print(data1)
#print(data2)

data = np.vstack((data1, data2))
#print(data)

model = cluster.KMeans(n_clusters=2)
model.fit(data)

labels = model.labels_

ldata = data[labels == 0]
plt.scatter(ldata[:, 0], ldata[:, 1], c='red', alpha=0.3, s=100, marker="o")

ldata = data[labels == 1]
plt.scatter(ldata[:, 0], ldata[:, 1], c='blue', alpha=0.3, s=100, marker="^")

