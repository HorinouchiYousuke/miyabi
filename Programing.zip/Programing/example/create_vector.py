# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 16:12:36 2019

@author: Y.H
"""

import numpy as np

def main(vectors):
    len_max = 0
    for i in range(len(vectors)):
        for j in vectors[i]:
            if(len(j) > len_max):
                len_max = len(vectors[i])
                
    print(len_max)
#    for i in range(len(vectors)):
#        for j in range(len(vectors[i])):
#            #print(len(vectors[i][j]))
#            np.append(vectors[i][j], np.zeros(len_max-len(vectors[i][j])))
            
    return vectors